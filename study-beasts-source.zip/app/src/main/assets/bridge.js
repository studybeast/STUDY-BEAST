/* Study Beasts app bridge (shared by the Android and desktop apps).
   Gives the page the same window.claude.use() it has inside claude.ai:
   - "sample": asks Claude through the Anthropic API with the key the user saves on this phone
   - "downloads": saves files through the Android or desktop app
   The API key is kept only on this device. */
(function () {
  var KEY_STORE = 'sb_api_key', MODEL_STORE = 'sb_model';
  var MODELS = { quick: 'claude-haiku-5-5', default: 'claude-sonnet-5-5', complex: 'claude-sonnet-5-5' };
  function getKey() { try { return localStorage.getItem(KEY_STORE) || ''; } catch (e) { return ''; } }
  function getModel() { try { return localStorage.getItem(MODEL_STORE) || ''; } catch (e) { return ''; } }
  function fail(code, message, text) { var e = new Error(message || code); e.code = code; e.message = message || code; if (text) e.text = text; return e; }

  function toMessages(input) {
    if (typeof input === 'string') return [{ role: 'user', content: input }];
    return (input || []).map(function (m) { return { role: m.role, content: String(m.content) }; });
  }

  async function ask(input, opts) {
    opts = opts || {};
    var key = getKey();
    if (!key) throw fail('not_granted', 'Add your Anthropic API key first.');
    var model = getModel() || MODELS[opts.modelTier || 'default'] || MODELS.default;
    var res;
    try {
      res = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        signal: opts.signal,
        headers: {
          'content-type': 'application/json',
          'x-api-key': key,
          'anthropic-version': '2023-06-01',
          'anthropic-dangerous-direct-browser-access': 'true'
        },
        body: JSON.stringify({ model: model, max_tokens: 8000, stream: true, messages: toMessages(input) })
      });
    } catch (e) {
      if (opts.signal && opts.signal.aborted) throw fail('cancelled', 'Stopped.');
      throw fail('network', 'No internet connection. Check your connection and try again.');
    }
    if (!res.ok) {
      var body = ''; try { body = await res.text(); } catch (e) {}
      if (res.status === 401) throw fail('not_granted', 'The API key was not accepted. Check it in AI key settings.');
      if (res.status === 429 || res.status === 529) throw fail('rate_limited', 'Claude is busy. Wait a minute and try again.');
      throw fail('error', 'Claude could not answer (' + res.status + ').');
    }
    var reader = res.body.getReader(), dec = new TextDecoder(), buf = '', text = '', stop = '';
    try {
      for (;;) {
        var r = await reader.read(); if (r.done) break;
        buf += dec.decode(r.value, { stream: true });
        var lines = buf.split('\n'); buf = lines.pop();
        for (var i = 0; i < lines.length; i++) {
          var l = lines[i]; if (l.indexOf('data:') !== 0) continue;
          var d; try { d = JSON.parse(l.slice(5)); } catch (e) { continue; }
          if (d.type === 'content_block_delta' && d.delta && d.delta.type === 'text_delta') {
            text += d.delta.text;
            if (opts.onText) { try { opts.onText({ text: text, delta: d.delta.text }); } catch (e) {} }
          } else if (d.type === 'message_delta' && d.delta && d.delta.stop_reason) {
            stop = d.delta.stop_reason;
          } else if (d.type === 'error') {
            throw fail('error', 'Claude stopped with an error. Try again.', text);
          }
        }
      }
    } catch (e) {
      if (opts.signal && opts.signal.aborted) throw fail('cancelled', 'Stopped.', text);
      if (e && e.code) throw e;
      throw fail('network', 'The connection dropped. Try again.', text);
    }
    return { text: text, truncated: stop === 'max_tokens', modelApplied: model };
  }

  function parseJSON(text) {
    var t = String(text || '').replace(/```(?:json)?/g, '');
    var a = t.indexOf('{'), b = t.lastIndexOf('}');
    var a2 = t.indexOf('['), b2 = t.lastIndexOf(']');
    if (a2 !== -1 && (a === -1 || a2 < a)) { a = a2; b = b2; }
    return JSON.parse(t.slice(a, b + 1));
  }

  var sample = function (input, opts) { return ask(input, opts); };
  sample.json = async function (input, opts) {
    var msgs = toMessages(input);
    msgs[msgs.length - 1].content += '\n\nReply with valid JSON only, no other text.';
    var r = await ask(msgs, opts);
    try { return parseJSON(r.text); } catch (e) { throw fail('invalid_json', 'Claude sent an answer that could not be read. Try again.', r.text); }
  };
  sample.limits = async function () { return { images: false }; };

  var downloads = {
    save: async function (o) {
      if (window.DesktopBridge) {
        var r = await window.DesktopBridge.saveFile(String(o.filename || 'study-beasts.html'), String(o.data || ''));
        if (r === 'declined') throw fail('declined', 'Save cancelled.');
        if (r !== 'ok') throw fail('error', 'Could not save the file.');
        return { saved: true };
      }
      if (!window.AndroidBridge) throw fail('unavailable', 'Saving needs the app.');
      var ok = window.AndroidBridge.saveFile(String(o.filename || 'study-beasts.html'), String(o.data || ''));
      if (!ok) throw fail('error', 'Could not save the file.');
      return { saved: true };
    }
  };

  window.claude = {
    use: async function (name) {
      if (name === 'sample') return getKey() ? sample : null;
      if (name === 'downloads') return (window.AndroidBridge || window.DesktopBridge) ? downloads : null;
      return null;
    }
  };

  /* AI key settings button and dialog */
  function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
  function buildUI() {
    var css = document.createElement('style');
    css.textContent =
      'body{padding-bottom:64px}#sbKeyBtn{position:fixed;right:calc(12px + env(safe-area-inset-right,0px));bottom:calc(12px + env(safe-area-inset-bottom,0px));z-index:50;border:2px solid var(--ink,#1E2B25);background:var(--surface,#fff);color:var(--ink,#1E2B25);border-radius:999px;padding:7px 12px;font:700 13px var(--body,sans-serif);box-shadow:2px 2px 0 var(--shadow,#1E2B25)}' +
      '#sbKeyBtn.off{background:var(--accent,#E8902A);color:#1E2B25}' +
      '#sbKeyDlg{position:fixed;inset:0;z-index:60;background:rgba(0,0,0,.45);display:grid;place-items:center;padding:16px}' +
      '#sbKeyDlg .box{background:var(--surface,#fff);color:var(--ink,#1E2B25);border:2px solid var(--ink,#1E2B25);border-radius:16px;padding:18px;max-width:440px;width:100%;display:flex;flex-direction:column;gap:10px;font:15px/1.5 var(--body,sans-serif)}' +
      '#sbKeyDlg h3{margin:0;font:600 1.2rem var(--display,sans-serif)}#sbKeyDlg p{margin:0;color:var(--muted,#56685E);font-size:.9rem}' +
      '#sbKeyDlg input,#sbKeyDlg select{font:inherit;padding:9px 11px;border:1px solid var(--line,#CFDDCB);border-radius:8px;background:var(--paper,#EAF4E4);color:inherit;width:100%;box-sizing:border-box}' +
      '#sbKeyDlg .row{display:flex;gap:8px;flex-wrap:wrap}#sbKeyDlg button{font:700 14px var(--body,sans-serif);padding:9px 16px;border-radius:999px;border:2px solid var(--ink,#1E2B25);background:var(--ink,#1E2B25);color:var(--paper,#fff)}' +
      '#sbKeyDlg button.g{background:transparent;color:var(--ink,#1E2B25)}';
    document.head.appendChild(css);
    var btn = document.createElement('button');
    btn.id = 'sbKeyBtn';
    function paint() { var on = !!getKey(); btn.textContent = on ? 'AI key ✓' : 'Add AI key'; btn.className = on ? '' : 'off'; }
    paint();
    btn.onclick = function () {
      var d = document.createElement('div'); d.id = 'sbKeyDlg';
      var m = getModel();
      d.innerHTML = '<div class="box" role="dialog" aria-label="AI key settings"><h3>Claude AI key</h3>' +
        '<p>Notes, test papers and answer marking use Claude through your own Anthropic API key. Create one at console.anthropic.com. The key is stored only on this device, and usage is billed to that account.</p>' +
        '<input id="sbKeyIn" type="password" autocomplete="off" placeholder="sk-ant-..." value="' + esc(getKey()) + '">' +
        '<select id="sbModelIn"><option value="">Automatic model</option><option value="claude-sonnet-5-5"' + (m === 'claude-sonnet-5-5' ? ' selected' : '') + '>Claude Sonnet 5.5 (best)</option><option value="claude-haiku-5-5"' + (m === 'claude-haiku-5-5' ? ' selected' : '') + '>Claude Haiku 5.5 (faster, cheaper)</option></select>' +
        '<div class="row"><button id="sbSave">Save</button><button class="g" id="sbRemove">Remove key</button><button class="g" id="sbClose">Close</button></div></div>';
      document.body.appendChild(d);
      var close = function () { d.remove(); };
      d.querySelector('#sbClose').onclick = close;
      d.onclick = function (e) { if (e.target === d) close(); };
      d.querySelector('#sbRemove').onclick = function () { try { localStorage.removeItem(KEY_STORE); } catch (e) {} location.reload(); };
      d.querySelector('#sbSave').onclick = function () {
        var k = d.querySelector('#sbKeyIn').value.trim(), mm = d.querySelector('#sbModelIn').value;
        try { if (k) localStorage.setItem(KEY_STORE, k); else localStorage.removeItem(KEY_STORE); if (mm) localStorage.setItem(MODEL_STORE, mm); else localStorage.removeItem(MODEL_STORE); } catch (e) {}
        location.reload();
      };
    };
    document.body.appendChild(btn);
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', buildUI); else buildUI();
})();
