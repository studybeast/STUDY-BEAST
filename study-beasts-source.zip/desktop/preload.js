const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('DesktopBridge', {
  saveFile: (filename, data) => ipcRenderer.invoke('save-file', { filename, data })
});
